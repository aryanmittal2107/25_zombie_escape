# Issues Found and Fixes

| Tool | Issue identified in original code | Fix applied |
|---|---|---|
| Bandit B403 / B301 | `pickle` import and pickle-based serialization/deserialization | Removed `pickle`; `snapshot()` now returns database query results directly. |
| Bandit B105 | Hard-coded password string | Removed the unused hard-coded password. |
| Bandit B608 | SQL query built with string formatting | Replaced string interpolation with parameterized SQL placeholders (`?`). |
| Pylint C0114 / C0116 | Missing module and function/method docstrings | Added module, class, and method/function docstrings. |
| Pylint C0103 | Non-standard names such as `addTower`, `serviceTower`, and `riskLevel` | Used snake_case names and consistent instance state. |
| Pylint W0603 | Use of `global` for `service_count` | Moved the counter into the `TowerMaintenance` instance. |
| Pylint W0718 | Catching the broad `Exception` type | Caught `sqlite3.Error` for database operations and added logging. |
| Pylint R1705 | Unnecessary `else` after `return` | Removed the unnecessary `else` branch. |
| Flake8 E501 / E303 / E225 | Long lines, excessive blank lines, and whitespace around an operator | Reformatted statements and normalized spacing. |

## Before-and-after results

- **Pylint:** 5.14/10 before; 10.00/10 after.
- **Bandit:** 4 findings before; no issues identified after.
- **Flake8:** 8 reported violations before; final report was empty, indicating no violations.
