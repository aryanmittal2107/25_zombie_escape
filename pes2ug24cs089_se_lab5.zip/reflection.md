# Reflection

## 1. What issues did the static-analysis tools identify?

The initial analysis identified code-quality, formatting, and security concerns. Pylint reported missing docstrings, non-standard naming, long lines, use of a global statement, broad exception handling, and an unnecessary `else` after a `return`. Flake8 reported long lines, excessive blank lines, and whitespace around an operator. Bandit flagged the use of `pickle`, a hard-coded password, and SQL query construction using string formatting, which can create a SQL-injection risk.

## 2. What changes were made to improve the code?

The code was reorganized into a `TowerMaintenance` class, with methods using snake_case names and docstrings explaining their purpose. SQL statements were changed to use parameterized queries. The pickle-based snapshot was replaced with a direct database query, and the hard-coded password was removed. Input validation, logging, database rollback on database errors, and a `close()` method were added. Formatting and control flow were also cleaned up.

## 3. What were the final static-analysis results?

Pylint improved from 5.14/10 to 10.00/10. Bandit reported no issues in the final scan. Flake8 produced no output in the final report, indicating that it found no violations. These results show an improvement in code style and in the specific risks checked by the tools.

## 4. What did you learn from this lab?

This lab demonstrated that static-analysis tools can identify issues before software is run or deployed. Pylint helps improve readability and maintainability, Flake8 checks style and formatting, and Bandit highlights certain security risks. I also learned that parameterized SQL queries are safer than building queries with string formatting, that unsafe deserialization should be avoided when unnecessary, and that clear naming, documentation, and focused exception handling make code easier to understand and maintain.

*Note: Static-analysis tools cannot guarantee that a program is completely free of defects or security vulnerabilities.*
